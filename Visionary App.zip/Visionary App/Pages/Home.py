import os
import tkinter as tk
import EHAJ_Tkinter as ctk
from PIL import Image
import pandas as pd
from utliz.LabelGrid import CTkLabelGrid as Grid

# Get the script directory path
script_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# Function to read Excel file and return records
def excel(file_path, sheet):
    # Read the Excel file
    df = pd.read_excel(file_path, sheet_name=sheet)
    
    # Convert the DataFrame to a list of tuples
    records = [tuple(row) for row in df.to_records(index=False)]
    records = records[0:]  # Remove the header row
    return records

# Home class for the Home screen
class Home(ctk.CTkFrame):

    def __init__(self, master, main):
        # Initialize the CTkFrame
        super().__init__(master)
        self.main = main
        self.initUI()

    def initUI(self):
        # Configure the main frame
        self.configure(corner_radius=0)
        
        # Create the central frame
        self.Home_CenFrame = ctk.CTkFrame(master=self, corner_radius=15, border_width=3)
        self.Home_CenFrame.place(relx=0.5, rely=0.5, anchor="center", relwidth=0.7, relheight=0.7)

        # Create a subframe within the central frame
        self.Home_SubFrame = ctk.CTkFrame(master=self.Home_CenFrame, fg_color="transparent")
        self.Home_SubFrame.pack(side=ctk.TOP, padx=10, pady=10, expand=True, fill="both")

        # Create two more subframes within the subframe
        self.Home_SubFrame0 = ctk.CTkFrame(master=self.Home_SubFrame, fg_color="transparent")
        self.Home_SubFrame0.pack(side=ctk.TOP, expand=True)
        self.Home_SubFrame1 = ctk.CTkFrame(master=self.Home_SubFrame, fg_color="transparent")
        self.Home_SubFrame1.pack(side=ctk.TOP, expand=True, fill="both")

        # Setting Visionary Warehouse logo
        self.Visionary_Img = Image.open(os.path.join(script_dir, "UI", "EHAJ_logo.png"))
        self.Visionary = ctk.CTkImage(self.Visionary_Img, size=(400, 250))
        self.Visionary_Label = ctk.CTkLabel(master=self.Home_SubFrame0, image=self.Visionary, text="")
        self.Visionary_Label.pack(padx=10, pady=10)

        # Create a frame for buttons
        self.Visionarybtns_Frame = ctk.CTkFrame(master=self.Home_SubFrame1, fg_color="transparent")
        self.Visionarybtns_Frame.pack(expand=True, fill="both")

        # Create a subframe within the buttons frame
        self.Visionarybtns_Frame1 = ctk.CTkFrame(master=self.Visionarybtns_Frame, fg_color="transparent")
        self.Visionarybtns_Frame1.pack(expand=True, fill="both", side=ctk.LEFT)
        
        # Create Import button
        self.Imports_Button = ctk.CTkButton(master=self.Visionarybtns_Frame, text="Imports", font=("Roboto", 50), command=lambda: self.main.show_frame(Imports))
        self.Imports_Button.pack(side=ctk.RIGHT, padx=15, pady=15, expand=True, fill="both")

        # Create Inventory button
        self.Inventory_Button = ctk.CTkButton(master=self.Visionarybtns_Frame, text="Inventory", font=("Roboto", 50), command=lambda: self.main.show_frame(Inventory))
        self.Inventory_Button.pack(side=ctk.LEFT, expand=True, fill="both", padx=15, pady=15)
        
        # Create Exports button
        self.Exports_Button = ctk.CTkButton(master=self.Visionarybtns_Frame1, text="Exports", font=("Roboto", 50), command=lambda: self.main.show_frame(Exports))
        self.Exports_Button.pack(expand=True, fill="both", padx=15, pady=15)

# Inventory class for the Inventory screen
class Inventory(ctk.CTkFrame):

    def __init__(self, master, main):
        # Initialize the CTkFrame
        super().__init__(master)
        self.main = main
        self.initUI()

    def initUI(self):
        # Configure the main frame
        self.configure(corner_radius=0)
        
        # Create the central frame
        self.Inventory_CenFrame = ctk.CTkFrame(master=self, corner_radius=15, border_width=3)
        self.Inventory_CenFrame.place(relx=0.5, rely=0.5, anchor="center", relwidth=0.9, relheight=0.9)

        # Create and pack the header label
        self.Head_Label = ctk.CTkLabel(self.Inventory_CenFrame, text="Inventory", font=("Roboto", 30))
        self.Head_Label.pack(side=ctk.TOP, pady=20, padx=10, fill="both")

        # Create and pack the Home button
        self.Home_Button = ctk.CTkButton(master=self.Inventory_CenFrame, text="Home", font=("Roboto", 20), command=lambda: self.main.show_frame_destroy_all(Home))
        self.Home_Button.pack(side=ctk.BOTTOM, pady=20, padx=10)
        
        # Set up headings and content for the inventory grid
        headings = {"00": "Product ID", "01": "Product Name", "02": "Quantity", "03": "Price", "04": "Active Shipments", "05": "Status"}
        self.content = excel(os.path.join(script_dir, "Data", "Warehouse_Data.xlsx"), sheet="Inventory")
        content_ = [tuple(str(item) for item in row[:-2]) for row in self.content]
        self.InvGrid = Grid(self.Inventory_CenFrame, headings=headings, content=content_, max_row_count=5, double_click_command=self.Item)
        self.InvGrid.pack(fill="both", expand=True, padx=10, pady=5)

    # Function to handle item selection from the grid
    def Item(self, data):
        index = int(data[0]) - 1
        row = self.content[index]
        details = row[7]
        img_path = os.path.join(script_dir, "Data", row[6])
        Popup_Frame = ctk.CTkFrame(self.main.container, corner_radius=0, fg_color="transparent")
        Popup_Frame.place(relwidth=1, relheight=1)

        # Create and place the popup central frame
        self.Popup_CenFrame = ctk.CTkFrame(master=Popup_Frame, corner_radius=15, border_width=3)
        self.Popup_CenFrame.place(relx=0.5, rely=0.5, anchor="center", relwidth=0.9, relheight=0.9)

        # Create and pack the header label in the popup
        Head_Label = ctk.CTkLabel(self.Popup_CenFrame, text=row[1], font=("Roboto", 30))
        Head_Label.pack(side=ctk.TOP, pady=20, padx=10, fill="both")

        # Load and display the image in the popup
        self.Img = Image.open(img_path)
        self.Img0 = ctk.CTkImage(self.Img, size=(250, 300))
        self.Img_Label = ctk.CTkLabel(master=self.Popup_CenFrame, image=self.Img0, text="")
        self.Img_Label.pack(padx=10, pady=10, expand=True)

        # Create and pack the Back button in the popup
        self.Back_Button = ctk.CTkButton(master=self.Popup_CenFrame, text="Back", font=("Roboto", 20), command=lambda: Popup_Frame.destroy())
        self.Back_Button.pack(side=ctk.BOTTOM, pady=10)

        # Create and pack the details label in the popup
        details_Label = ctk.CTkLabel(self.Popup_CenFrame, text=details, font=("Roboto", 20))
        details_Label.pack(side=ctk.BOTTOM, pady=20, padx=10, fill="both")

# Imports class for the Imports screen
class Imports(ctk.CTkFrame):

    def __init__(self, master, main):
        # Initialize the CTkFrame
        super().__init__(master)
        self.main = main
        self.initUI()

    def initUI(self):
        # Configure the main frame
        self.configure(corner_radius=0)
        
        # Create the central frame
        self.Imports_CenFrame = ctk.CTkFrame(master=self, corner_radius=15, border_width=3)
        self.Imports_CenFrame.place(relx=0.5, rely=0.5, anchor="center", relwidth=0.9, relheight=0.9)

        # Create and pack the header label
        self.Head_Label = ctk.CTkLabel(self.Imports_CenFrame, text="Imports", font=("Roboto", 30))
        self.Head_Label.pack(side=ctk.TOP, pady=20, padx=10, fill="both")

        # Create and pack the Home button
        self.Home_Button = ctk.CTkButton(master=self.Imports_CenFrame, text="Home", font=("Roboto", 20), command=lambda: self.main.show_frame_destroy_all(Home))
        self.Home_Button.pack(side=ctk.BOTTOM, pady=20, padx=10)

        # Set up headings and content for the imports grid
        headings = {"00": "Shipment ID", "01": "Product ID", "02": "Product Name", "03": "Quantity", "04": "Expected Delivery Date", "05": "Status"}
        content = excel(os.path.join(script_dir, "Data", "Warehouse_Data.xlsx"), sheet="Imports")
        content = [tuple(str(item) for item in row) for row in content]
        self.InvGrid = Grid(self.Imports_CenFrame, headings=headings, content=content, max_row_count=5)
        self.InvGrid.pack(fill="both", expand=True, padx=10, pady=5)

# Exports class for the Exports screen
class Exports(ctk.CTkFrame):

    def __init__(self, master, main):
        # Initialize the CTkFrame
        super().__init__(master)
        self.main = main
        self.initUI()

    def initUI(self):
        # Configure the main frame
        self.configure(corner_radius=0)
        
        # Create the central frame
        self.Exports_CenFrame = ctk.CTkFrame(master=self, corner_radius=15, border_width=3)
        self.Exports_CenFrame.place(relx=0.5, rely=0.5, anchor="center", relwidth=0.9, relheight=0.9)

        # Create and pack the header label
        self.Head_Label = ctk.CTkLabel(self.Exports_CenFrame, text="Exports", font=("Roboto", 30))
        self.Head_Label.pack(side=ctk.TOP, pady=20, padx=10, fill="both")

        # Create and pack the Home button
        self.Home_Button = ctk.CTkButton(master=self.Exports_CenFrame, text="Home", font=("Roboto", 20), command=lambda: self.main.show_frame_destroy_all(Home))
        self.Home_Button.pack(side=ctk.BOTTOM, pady=20, padx=10)

        # Set up headings and content for the exports grid
        headings = {"00": "Shipment ID", "01": "Product ID", "02": "Product Name", "03": "Quantity", "04": "Total Cost", "05": "Status", "06": "Expected Delivery Date"}
        content = excel(os.path.join(script_dir, "Data", "Warehouse_Data.xlsx"), sheet="Exports")
        content = [tuple(str(item) for item in row) for row in content]
        self.InvGrid = Grid(self.Exports_CenFrame, headings=headings, content=content, max_row_count=5)
        self.InvGrid.pack(fill="both", expand=True, padx=10, pady=5)
