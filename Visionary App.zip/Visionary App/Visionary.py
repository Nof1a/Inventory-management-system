import tkinter as tk
import EHAJ_Tkinter as ctk
from Pages.Home import Home
from utliz.maping import center_element

class MainApp:

    def __init__(self, root):
        self.root = root
        ctk.set_appearance_mode("dark")  # Set the appearance mode to dark
        ctk.set_default_color_theme("EHAJ")  # Set the default color theme
        self.frames = {}  # Dictionary to hold frame instances
        self.search_frame = False
        # Create the back frame
        self.back_frame = ctk.CTkFrame(self.root)
        self.back_frame.grid(row=0, column=0, sticky="nsew")

        self.container = ctk.CTkFrame(self.back_frame)  # Container for holding frames
        self.container.place(relwidth=1, relheight=1)
        # Initialize the first frame
        self.show_frame(Home)

    def show_frame(self, frame_class):
        '''Create instance if it doesn't exist and raise to the front'''
        self.search_frame = False
        self.current_frame_class = frame_class
        # Check if the frame already exists
        if frame_class not in self.frames:
            frame_instance = frame_class(self.container, self)
            self.show_loading_screen()
            frame_instance.place(relwidth=1, relheight=1)
            self.frames[frame_class] = frame_instance

        self.cancel_loading_screen = self.root.after(1000, self.hide_loading_screen)

    def show_frame_destroy(self, frame_class):
        self.destroy_frame(self.current_frame_class)  # Destroy the current frame
        '''Create instance if it doesn't exist and raise to the front'''
        self.search_frame = False
        self.current_frame_class = frame_class
        # Check if the frame already exists
        if frame_class not in self.frames:
            frame_instance = frame_class(self.container, self)
            self.show_loading_screen()
            frame_instance.place(relwidth=1, relheight=1)
            self.frames[frame_class] = frame_instance

        self.cancel_loading_screen = self.root.after(1000, self.hide_loading_screen)

    def show_frame_destroy_all(self, frame_class):
        # Destroy all existing frames
        for frame in list(self.frames.keys()):
            self.destroy_frame(frame)

        '''Create instance if it doesn't exist and raise to the front'''
        self.search_frame = False
        self.current_frame_class = frame_class
        # Check if the frame already exists
        if frame_class not in self.frames:
            frame_instance = frame_class(self.container, self)
            self.show_loading_screen()
            frame_instance.place(relwidth=1, relheight=1)
            self.frames[frame_class] = frame_instance

        self.cancel_loading_screen = self.root.after(1200, self.hide_loading_screen)

    def destroy_frame(self, frame_class):
        self.frames[frame_class].destroy()  # Destroy the frame instance
        del self.frames[frame_class]  # Remove the frame from the dictionary

    def show_loading_screen(self):
        if self.search_frame == False and not hasattr(self, "loading_label"):
            # Create a label with "Loading..." text on the back frame
            self.loading_label = ctk.CTkLabel(self.back_frame, text="Loading...", font=("Roboto", 100))
            self.loading_label.place(relheight=1, relwidth=1)

    def hide_loading_screen(self):
        if hasattr(self, "loading_label"):
            self.loading_label.destroy()  # Destroy the loading label
            del self.loading_label

    def show_error_popup(self, error_message):
        # First, create a full size frame that covers everything (this can be used as a semi-transparent overlay if desired)
        self.overlay = ctk.CTkFrame(master=self.root)
        self.overlay.place(x=0, y=0, relwidth=1, relheight=1)

        # Then, create the actual popup frame to show the error
        self.error_popup = ctk.CTkFrame(master=self.overlay)  # Setting overlay as master

        # Display the error message
        lbl_error = ctk.CTkLabel(self.error_popup, text=str(error_message), font=("Roboto", 20))
        lbl_error.pack(pady=20, padx=10)

        # Close button to close the error popup
        btn_close = ctk.CTkButton(self.error_popup, text="Back", command=self.close_error_popup)
        btn_close.pack(pady=10)

        # This function will center the error_popup inside the overlay
        center_element(self.error_popup)

    def close_error_popup(self):
        self.error_popup.destroy()  # Destroy the error popup
        self.overlay.destroy()  # Destroy the overlay

def handle_exception(exc_type, exc_value, exc_traceback):
    app.show_error_popup(exc_value)  # Show error popup with the exception value

if __name__ == "__main__":
    root = ctk.CTk()
    root.report_callback_exception = handle_exception  # Set the exception handler
    root.grid_rowconfigure(0, weight=1)
    root.grid_columnconfigure(0, weight=1)
    root.grid_propagate(False)
    root.geometry("1200x600")  # Set the window size
    root.title("Visionary")  # Set the window title
    app = MainApp(root)  # Create the main application instance

    root.mainloop()  # Start the main loop
