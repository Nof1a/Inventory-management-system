import os
import sys
import tkinter as tk
import EHAJ_Tkinter as ctk
import math
from .arabic import reverse_arabic_blocks as ar
from .export import print_file as PDF
from .export import export_to_excel as Excel
import numpy as np

class NoOptionsSelectedError(Exception):
    pass
class CTkToolTip:
    def __init__(self, widget, text):
        self.widget = widget
        self.text = text
        self.tooltip_window = None
        self.tooltip_after_id = None
        self.widget.bind("<Enter>", self.on_enter)
        self.widget.bind("<Leave>", self.on_leave)

    def on_enter(self, event=None):
        if self.tooltip_after_id:
            self.widget.after_cancel(self.tooltip_after_id)
            self.tooltip_after_id = None
        self.tooltip_after_id = self.widget.after(300, self.show_tooltip)  # delay of 500ms

    def show_tooltip(self):
        x, y, _, _ = self.widget.bbox("insert")
        x += self.widget.winfo_rootx() + 20
        y += self.widget.winfo_rooty() + 20
        self.tooltip_window = ctk.CTkToplevel(self.widget)
        self.tooltip_window.wm_overrideredirect(True)
        self.tooltip_window.wm_geometry(f"+{x}+{y}")
        label_frame= ctk.CTkFrame(self.tooltip_window,border_width=1,corner_radius=0)
        label = ctk.CTkLabel(label_frame, text=self.text)
        label_frame.pack()
        label.pack(pady=10,padx=10)

    def on_leave(self, event=None):
        if self.tooltip_after_id:
            self.widget.after_cancel(self.tooltip_after_id)
            self.tooltip_after_id = None
        if self.tooltip_window:
            self.tooltip_window.destroy()

class CTkSelectMenu:
    def __init__(self, master, options_dict=None, update_variable=None, command=None, width=None, height=None, window_btn_text=None,
                 window_label_text="Select your options", submit_btn_text="Submit", tooltip_text="Pop-up text",
                 max_options_per_column=5):

        self.master = master
        self.options_dict = options_dict if options_dict else {}
        self.update_variable = update_variable
        self.command = command
        self.window_label_text = window_label_text
        self.submit_btn_text = submit_btn_text
        self.max_options_per_column = max_options_per_column
        
        # Create a Select button
        self.button = ctk.CTkButton(master, text=window_btn_text if window_btn_text is not None else "Select Menu", command=self.open_options_window, 
                                    width=width if width is not None else 128, height=height if height is not None else 28)
        self.button.pack(pady=20)
        
        # Add tooltip to the button
        self.tooltip = CTkToolTip(self.button, tooltip_text)
        
    def open_options_window(self):
        # Create a new window
        self.new_window = ctk.CTkToplevel(self.master)
        self.new_window.title("Select Options")
        window_frame = ctk.CTkFrame(self.new_window, border_width=1)
        window_frame.pack(fill="both", expand=True)

        # Grid layout for checkboxes
        self.check_vars = {}
        keys_list = list(self.options_dict.keys())
        row_width = int(np.ceil(len(keys_list)/self.max_options_per_column))
        
        # Create a label at the top
        label = ctk.CTkLabel(window_frame, text=self.window_label_text)
        label.grid(row=0, column=0, columnspan=row_width-1 if row_width !=1 else 1, pady=10, padx=15)

        self.header_var = tk.BooleanVar(value=False)
        header_checkbox = ctk.CTkCheckBox(window_frame, text="Select All", variable=self.header_var, command=self.toggle_all)
        header_checkbox.grid(row=0, column=row_width-1 if row_width !=1 else 1, sticky='w', padx=7)  # Place it next to the label
        
        # This line makes the new window modal
        self.new_window.grab_set()

        row_list= []
        col_list= []
        ids=0
        for i in range(len(keys_list)):
            row_list.append(ids)
            col_list.append(i % row_width)
            if (i+1)%row_width == 0:
                ids += 1 

        for row, col, key in zip(row_list, col_list, keys_list):
            check_var = tk.BooleanVar()
            checkbox = ctk.CTkCheckBox(window_frame, text=self.options_dict[key], variable=check_var)
            checkbox.grid(row=row+1, column=col, sticky='w', padx=7, pady=7)  # +1 for the label row
            self.check_vars[key] = check_var

        # Determine grid position for Submit button
        total_rows = self.max_options_per_column + 1 if len(keys_list) >= self.max_options_per_column else len(keys_list) +1
        ctk.CTkButton(window_frame, text=self.submit_btn_text, command=self.retrieve_values).grid(row=total_rows+1, column=0, columnspan=2, pady=10)

        # Make the window lose focus when 'X' is clicked
        self.new_window.protocol("WM_DELETE_WINDOW", self.new_window.destroy)
    
    def toggle_all(self):
        state = self.header_var.get()
        for check_var in self.check_vars.values():
            check_var.set(state)
    
    def retrieve_values(self):
        selected_options = {}

        for key, var in self.check_vars.items():
            if var.get():
                selected_options[key] = self.options_dict[key]
        
        if selected_options == {}:
            self.new_window.destroy()
            self.master.focus_set()
            raise NoOptionsSelectedError("No options are selected, if you wish to cancel press the X button")
        
        # Update the specified variable
        if self.update_variable is not None:
            self.update_variable.clear()
            for key, value in selected_options.items():
                self.update_variable[key]= value
        
        # Execute the optional command if provided
        if self.command:
            self.command()
        
        self.new_window.destroy()
        self.master.focus_set()

class NoRowsSelectedError(Exception):
    pass

class CTkLabelGrid(ctk.CTkFrame):
    def __init__(self, master, headings=None, content=None, buttons=True, intial_headings=None ,fg_color="transparent",
                 double_click_command=None,max_row_count=10,blocked_columns=None,old_size=[1200,600], *args, **kwargs):
        if isinstance(content, list) and all(isinstance(row, tuple) for row in content):
            content = tuple([list(row) for row in content])
        ctk.CTkFrame.__init__(self, master, corner_radius=7 , fg_color=fg_color,*args, **kwargs)
        self.headings = intial_headings
        self.back_frame=ctk.CTkFrame(self,border_width=3, corner_radius=7 )
        self.back_frame.pack(expand=True,pady=5,padx=5)
        self.master=master
        self.headings=headings
        self.blocked_columns = blocked_columns if blocked_columns is not None else []
        self.full_content = content
        self.content= self.filter_content()
        self.old_size=old_size
        self.buttons=buttons
        self.max_row_count=max_row_count
        self.pages_number=math.ceil(len(self.content)/self.max_row_count)
        self.double_click_command = double_click_command
        self.header_checkbox_var = tk.BooleanVar(value=False)
        self.checkboxes = []
        self.selected_rows =  set() # Set to store selected row indices
        self.choosed_content = None  # Variable to store double-clicked content
        self.edit_mode = False  # Flag to track whether edit mode is active
        self.entry_vars = []
        self.entry_list = []
        if content ==[] or content==tuple():  
            self._display_headings(False)
        else:
            self._create_labels()
            self._display_labels()
        self._display_buttons()

    def modify_table(self):
        self.content=self.filter_content()
        self.reload_all()
        self.configure_size()

    def filter_content(self):
        filtered_content = []
        for row in self.full_content:
            row_content = []
            for key in self.headings.keys():
                i= int(key[:2])
                row_content.append(row[i])
            filtered_content.append(row_content)
        return filtered_content

    def _create_labels(self):
        self.inner_frames=[]
        for i in range(self.pages_number):
            self.inner_frames.append(ctk.CTkFrame(master=self.back_frame, fg_color="transparent" , corner_radius=7))
        self.content_size = (len(self.content), len(self.content[0]))
        def __put_content_in_label(row, column):
            content = self.content[row][column]
            content_type = type(content).__name__
            if content_type in ('str', 'int'):
                self.labels[row][column].configure(text=ar(str(content)))

        self.labels = []
        self.label_frames = []  # Store the CTkFrame containers for the labels
        pageIndex = 0  # Use pageIndex for more clarity than 'x'
        for i in range(self.content_size[0]):
            if i != 0 and i % self.max_row_count == 0:
                pageIndex += 1
            self.checkboxes.append(tk.BooleanVar(value=False))  # <-- Add this line
            self.labels.append([])
            self.label_frames.append([])  # Initialize list for this row
            for j in range(self.content_size[1]):
                label_frame = ctk.CTkFrame(self.inner_frames[pageIndex], border_width=1, corner_radius=3, fg_color="transparent")
                self.label_frames[i].append(label_frame)  # Store the CTkFrame
                label = ctk.CTkLabel(label_frame, font=("Roboto", 15), fg_color="transparent")  # Parent is the label_frame
                label.pack(expand=True, fill="both", padx=5, pady=5)  # Adjust padding as needed
                self.labels[i].append(label)
                __put_content_in_label(i, j)
                label.bind("<Double-1>", lambda event, row=i: self.double_click_row(row))
                label_frame.bind("<Double-1>", lambda event, row=i: self.double_click_row(row))
                label.bind("<Button-3>", lambda event, label=label: self.copy_cell(label))
                label_frame.bind("<Button-3>", lambda event, label=label: self.copy_cell(label))
        self.inner_frames[0].pack(fill="both",padx=5,pady=5, ipadx=0.5,ipady=0.5)
        self.inner_frame_index=0
        
    def _display_headings(self,content):
        # Create header row
        if self.headings:
            self.headings_labels=[]
            row_index=0
            for_value= self.inner_frames if content==True else [self.back_frame]
            for inner in for_value:
                self.headings_labels.append([])
                self.header_label_frames = []  # A list to store the CTkFrame containers for the header labels
                for j, heading in enumerate(self.headings.values()):
                    header_label_frame = ctk.CTkFrame(inner, border_width=1, corner_radius=3, fg_color="#4934A3")  # Create a CTkFrame for each header label
                    header_label_frame.grid(row=0, column=j + 1, sticky="nsew",padx=0.5,pady=0.5)  # Grid the frame
                    self.headings_labels[row_index].append(ctk.CTkLabel(header_label_frame, text=ar(heading), font=("Roboto",18, "bold"), text_color=header_label_frame.cget("bg_color"))) # Parent is the header_label_frame
                    self.headings_labels[row_index][j].pack(padx=4, pady=4)  # Adjust padding as needed
                    self.header_label_frames.append(header_label_frame)  # Append the frame to the list
                row_index+=1

    def _display_labels(self):
        self._display_headings(True)
        self.header_checkboxes=[]
        pageIndex = 0
        for inner in self.inner_frames:
            # Create header checkbox
            header_checkbox_frame = ctk.CTkFrame(inner, border_width=1, corner_radius=3, fg_color="#4934A3")  # CTkFrame for the header checkbox
            header_checkbox_frame.grid(row=0, column=0, sticky="nsew", padx=0.5, pady=0.5)  # Grid the frame
            self.header_checkboxes.append(ctk.CTkCheckBox(header_checkbox_frame, variable=self.header_checkbox_var, command=self.toggle_all, border_color=header_checkbox_frame.cget("bg_color"),checkmark_color="#4934A3"))
            self.header_checkboxes[pageIndex].pack(padx=5, pady=8)  # Adjust padding as needed
            pageIndex += 1
        
        # For each content label, grid its parent CTkFrame
        # Also, create a frame for checkboxes
        self.checkbox_frames = []
        self.checkbox_list=[]
        pageIndex = 0
        for i in range(self.content_size[0]):
            if i != 0 and i % self.max_row_count == 0:
                pageIndex += 1
            checkbox_frame = ctk.CTkFrame(self.inner_frames[pageIndex], border_width=1, corner_radius=3, fg_color="#4934A3")  # CTkFrame for each checkbox in content rows
            checkbox_frame.grid(row=i + 1, column=0, sticky="nsew", padx=0.5, pady=0.5)  # Grid the frame
            self.checkbox_list.append(ctk.CTkCheckBox(checkbox_frame, variable=self.checkboxes[i], command=lambda row=i: self.toggle_row(row), border_color=checkbox_frame.cget("bg_color"), checkmark_color="#4934A3"))
            self.checkbox_list[i].pack(padx=5,pady=8)  # Adjust padding as needed
            self.checkbox_frames.append(checkbox_frame)  # Append the frame to the list

            for j in range(self.content_size[1]):
                self.label_frames[i][j].grid(row=i + 1, column=j + 1, sticky="nsew", padx=0.5,pady=0.5)
        
    def _display_buttons(self):
        if self.buttons==True:
            self.buttons_frame=ctk.CTkFrame(self,fg_color="transparent")
            self.buttons_frame.pack(expand=True,side=ctk.BOTTOM,pady=10,padx=10)
            self.previous_button=ctk.CTkButton(self.buttons_frame,text="\u2190", font=("Roboto",20),command=self.previous_page)
            self.previous_button.pack(side=ctk.LEFT, padx=15)
            self.next_button=ctk.CTkButton(self.buttons_frame,text="\u2192", font=("Roboto",20),command=self.next_page)
            self.next_button.pack(side=ctk.LEFT, padx=15)

    def configure_size(self,new_size=None):
        if new_size is not None:
            self.new_size = new_size
        scale=(self.new_size[1]/self.old_size[1]) if hasattr(self, 'new_size') else 1
        self.previous_button.configure(font=("Roboto", 20*scale))
        self.next_button.configure(font=("Roboto", 20*scale))
        self.select_button.button.configure(font=("Roboto", 16*scale,"bold"))
        if scale<=1:
            for header_checkbox in self.header_checkboxes if hasattr(self, 'header_checkboxes') and self.full_content != [] else []:
                header_checkbox.configure(checkbox_width=24, checkbox_height=24,border_width=3)
            for checkbox in self.checkbox_list if hasattr(self, 'checkbox_list') and self.full_content != [] else []:
                checkbox.configure(checkbox_width=24, checkbox_height=24,border_width=3)
            for widget in self.entry_list:
                if isinstance(widget, ctk.CTkEntry):
                    widget.configure(font=("Roboto", 13))
            for row in self.labels if hasattr(self, 'labels') and self.full_content != [] else []:
                for label in row:
                    label.configure(font=("Roboto", 15))
            for row in self.headings_labels:
                for label in row:
                    label.configure(font=("Roboto", 18,"bold"))
        else:
            for header_checkbox in self.header_checkboxes if hasattr(self, 'header_checkboxes') and self.full_content != [] else []:
                header_checkbox.configure(checkbox_width=24*scale, checkbox_height=24*scale)
            for checkbox in self.checkbox_list if hasattr(self, 'checkbox_list') and self.full_content != [] else []:
                checkbox.configure(checkbox_width=24*scale, checkbox_height=24*scale)
            for widget in self.entry_list:
                if isinstance(widget, ctk.CTkEntry):
                    widget.configure(font=("Roboto", 13*scale*1.3))
            for row in self.labels if hasattr(self, 'labels') and self.full_content != [] else []:
                for label in row:
                    label.configure(font=("Roboto", 15*scale*1.3))
            for row in self.headings_labels:
                for label in row:
                    label.configure(font=("Roboto", 18*scale*1.3,"bold"))

    def copy_cell(self, label):
        self.clipboard_clear()
        self.clipboard_append(ar(label.cget("text")))
        copy_label = ctk.CTkLabel(label, font=("Roboto", 15), text="Item Copied")
        copy_label.place(relx=0.5, rely=0, anchor=ctk.N, relheight=0, relwidth=1)
        
        
        # Define the sizes for the label animation
        num_elements = 100
        sizes = [i / 100 for i in range(1, num_elements + 1)] + [i / 100 for i in range(num_elements, -1, -1)]
        
        def animate_label(size_index=0):
            # If we still have sizes to process, resize the label and schedule the next size change
            if size_index < len(sizes):
                copy_label.place_configure(relheight=sizes[size_index])
                self.after(2, animate_label, size_index + 1)
            else:
                copy_label.destroy()  # Destroy the label after the animation is finished

        # Start the animation
        animate_label()

    def next_page(self):
        if hasattr(self, 'inner_frame_index') and self.inner_frame_index < len(self.inner_frames) - 1:  # Ensure we don't go beyond the last page
            self.inner_frames[self.inner_frame_index].pack_forget()
            self.inner_frame_index += 1
            self.inner_frames[self.inner_frame_index].pack(fill="both", padx=5, pady=5, ipadx=0.5, ipady=0.5)

    def previous_page(self):
        if hasattr(self, 'inner_frame_index') and self.inner_frame_index > 0:  # Ensure we don't go below the first page
            self.inner_frames[self.inner_frame_index].pack_forget()
            self.inner_frame_index -= 1
            self.inner_frames[self.inner_frame_index].pack(fill="both", padx=5, pady=5, ipadx=0.5, ipady=0.5)


    def toggle_all(self):
        all_checked = self.header_checkbox_var.get()
        for checkbox_var in self.checkboxes:
            checkbox_var.set(all_checked)
        self.update_selected_rows()

    def toggle_row(self, row):
        self.update_selected_rows()

    def update_selected_rows(self):
        self.selected_rows.clear()
        for row, checkbox_var in enumerate(self.checkboxes):
            if checkbox_var.get():
                self.selected_rows.add(row)



    def double_click_row(self, row):
        self.choosed_content = self.full_content[row]
        if self.double_click_command:
            self.double_click_command(self.choosed_content)



    def edit_selected_rows(self):
        if not self.selected_rows:
            raise NoRowsSelectedError("No rows are selected for editing!")
        if not self.edit_mode:
            self.edit_mode = True
            self.entry_vars = []  # Clear existing entry variables
            self.entry_list=[] 
            for row in self.selected_rows:
                entry_vars_row = []  # Entry variables for the current row
                for col in range(self.content_size[1]):
                    content = self.content[row][col]
                    entry_var = tk.StringVar(value=content)
                    if self.headings_labels[0][col].cget("text") in self.blocked_columns.values():  # Skip blocked columns
                        entry_vars_row.append(None)
                    else:
                        entry_vars_row.append(entry_var)
                        # Using the width and adjusting pady to match the height
                        entry = ctk.CTkEntry(self.labels[row][col].master.master,textvariable=entry_var, width=10, height=10)
                        entry.grid(row=row + 1, column=col + 1, sticky="nsew", pady=3,padx=3)
                        self.entry_list.append(entry)
                self.entry_vars.append(entry_vars_row)  # Append the entire row to entry_vars
            scale=1.3*(self.new_size[1]/self.old_size[1]) if hasattr(self, 'new_size') else 1
            for widget in self.entry_list:
                if isinstance(widget, ctk.CTkEntry):
                    widget.configure(font=("Roboto", 13*scale))



    def rows_with_entry_fields(self):
        entry_rows = set()
        for inner in self.inner_frames:
            for widget in inner.grid_slaves():
                if isinstance(widget, ctk.CTkEntry):
                    entry_rows.add(widget.grid_info()['row'] - 1)  # Subtracting 1 to account for the header row offset
        return entry_rows

    def save_changes(self):
        changed_rows = set()  # Use a set to store changed rows indices
        if self.edit_mode:
            sorted_selected_rows = sorted(list(self.selected_rows))
            for row, entry_vars_row in zip(sorted_selected_rows, self.entry_vars):
                for col, entry_var in enumerate(entry_vars_row):
                    if col not in self.blocked_columns and entry_var is not None:
                        # Check if the content has changed before updating
                        if str(self.content[row][col]) != entry_var.get():
                            self.content[row][col] = entry_var.get()
                            changed_rows.add(row)  # Add the row to changed_rows set
            self.edit_mode = False
            self.entry_vars.clear()
            self.edited_rows= [self.full_content[row] for row in self.selected_rows]
        
        for row in range(len(self.full_content)):
            for j ,key in enumerate(self.headings.keys()):
                col=int(key[:2])
                self.full_content[row][col] = self.content[row][j]
        
        return self.selected_rows

    def reload_table(self, rows_to_reload=None):
        if rows_to_reload == set() or rows_to_reload==None:
            rows_to_reload= self.rows_with_entry_fields()

        if rows_to_reload is not set():
            # If there are rows to reload, update only those rows
            for row in rows_to_reload:
                for col in range(self.content_size[1]):
                    content = self.content[row][col]
                    self.labels[row][col].configure(text=ar(content))
                    # Destroy the corresponding entry widget for that cell
                    parent_widget = self.labels[row][col].master.master
                    for widget in parent_widget.grid_slaves(row=row+1, column=col+1):
                        if isinstance(widget, ctk.CTkEntry):
                            widget.destroy()
                            del widget


        # Uncheck all the checkboxes
        for checkbox in self.checkboxes:
            checkbox.set(0)

        # Reset header checkbox if checked
        self.header_checkbox_var.set(False)
        self.selected_rows.clear()
        self.entry_list.clear()

    def save_changes_reload(self):
        rows_to_reload = self.save_changes()  # This will save changes and return the indices that changed
        self.reload_table(rows_to_reload)
    
    def reload_all(self):
        if hasattr(self, 'inner_frames'):
            for inner in self.inner_frames:
                inner.destroy()
            self.inner_frames.clear()
            self.selected_rows.clear()
            if hasattr(self, 'edited_rows'):
                self.edited_rows.clear() 
            for checkbox in self.checkboxes:
                checkbox.set(0)
            if self.full_content ==[] or self.full_content==None:  
                self._display_headings(False)
            else:
                self._create_labels()
                self._display_labels()
            self.entry_list.clear()
        else:
            self._display_headings(False)

    def export_pdf(self):
        data=[]
        data.append(self.headings.values())
        data+= self.content
        PDF(data)
    
    def export_excel(self):
        data=[]
        data.append(self.headings.values())
        data+= self.content
        Excel(data)

