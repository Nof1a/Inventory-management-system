import re

def reverse_arabic_blocks(text):
    try:
        text = text.lstrip()  # Remove leading spaces

        # Check if the first character of the text is Arabic
        arabic_range = [0x0600, 0x06FF]
        is_start_arabic = arabic_range[0] <= ord(text[0]) <= arabic_range[1]

        # Depending on the first character, set patterns for "arabic" and "non_arabic"
        if is_start_arabic:
            arabic_pattern = r'[\u0600-\u06FF0-9]'
            non_arabic_pattern = r'[a-zA-Z]'
        else:
            arabic_pattern = r'[\u0600-\u06FF]'
            non_arabic_pattern = r'[a-zA-Z0-9]'

        # Nested function to handle the reversing within the regex substitution
        def reverse_match(match):
            return ' '.join(reversed(match.group(0).split()))

        # Construct the pattern based on the above decisions
        pattern = rf'((?:{arabic_pattern}+\s*)+)(?=\s*[^{arabic_pattern}]|\Z)'
        reversed_text = re.sub(pattern, reverse_match, text)

        # Handle the space when switching between different scripts
        reversed_text = re.sub(rf'({arabic_pattern}+)([^\s{arabic_pattern}]+)', rf'\1 \2', reversed_text)
        reversed_text = re.sub(rf'([^\s{arabic_pattern}]+)({arabic_pattern}+)', rf'\1 \2', reversed_text)

        return reversed_text
    except Exception:
        return text
    


    


