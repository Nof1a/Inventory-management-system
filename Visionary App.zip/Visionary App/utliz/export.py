import webbrowser
import os
import tempfile
from openpyxl import Workbook
import tkinter as tk
from tkinter import filedialog


def print_file(data):
    # Convert data to HTML table
    html_content = """
    <html>
    <body>
    <table border='1'>
    """
    for row in data:
        html_content += "<tr>"
        for column in row:
            if column is None:
                column = ""
            html_content += f"<td>{column}</td>"
        html_content += "</tr>"
    html_content += "</table>"

    # Add JavaScript to trigger print dialog
    html_content += """
    <script type="text/javascript">
        window.onload = function() {
            window.print();
        }
    </script>
    </body>
    </html>
    """

    # Save to a temporary file
    temp_file = tempfile.NamedTemporaryFile(delete=False, suffix=".html")
    with open(temp_file.name, "w") as f:
        f.write(html_content)

    # Open in default web browser in a new window
    webbrowser.open('file://' + os.path.realpath(temp_file.name))

def export_to_excel(data):
    # Create a new Excel workbook and select the active worksheet
    wb = Workbook()
    ws = wb.active

    # Populate the worksheet with data
    for row in data:
        ws.append(row)

    # Open the save file dialog
    root = tk.Tk()
    root.withdraw()  # Hide the main window
    filepath = filedialog.asksaveasfilename(defaultextension=".xlsx",
                                             filetypes=[("Excel files", "*.xlsx"), ("All files", "*.*")])

    # If a filepath is selected, save the workbook
    if filepath:
        wb.save(filepath)