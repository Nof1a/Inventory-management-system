import tkinter as tk




def center_element(element):
    root = element.master
    

    def update_center(event=None):
        element.update_idletasks()
        root.update_idletasks()
        width = root.winfo_width()
        height = root.winfo_height()

        element.place(x=width//2, y=height//2 , anchor="center")

    # Call the function once to set initial position
    update_center()
    
    # Bind the function to root's configure event
    root.bind("<Configure>", update_center)